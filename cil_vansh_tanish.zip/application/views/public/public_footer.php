<script type='text/javascript' src="<?php echo base_url('assets/js/sample.js') ?>"></script>
</body>
</html>