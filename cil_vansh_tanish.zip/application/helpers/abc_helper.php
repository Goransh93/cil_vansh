<?php
function test(){
	echo "test function from ABC Helper";
}