<?php
function element(){
	echo "function overwritten";
}

