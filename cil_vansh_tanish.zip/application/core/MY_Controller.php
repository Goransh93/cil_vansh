<?php
class MY_Controller extends CI_Controller{

	
}


?>